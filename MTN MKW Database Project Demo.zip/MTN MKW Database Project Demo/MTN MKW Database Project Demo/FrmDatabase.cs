﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MTN_MKW_Database_Project_Demo
{
    public partial class FrmDatabase : Form
    {
        public FrmDatabase()
        {
            InitializeComponent();
        }

        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\30550602\Desktop\MTN MKW Database Project Demo\MTN MKW Database Project Demo\flightDatabase.mdf;Integrated Security=True";
        public SqlConnection connect;
        public SqlCommand command;
        public SqlDataAdapter adapter;
        public DataSet data;

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            string selectQuery = "SELECT * FROM tblFlights";

            try
            {
                connect = new SqlConnection(connectionString);

                connect.Open();

                command = new SqlCommand(selectQuery, connect);
                data = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = command;
                adapter.Fill(data, "tblFlights");

                dataGridView1.DataSource = data;
                dataGridView1.DataMember = "tblFlights";

                connect.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnViewDomestic_Click(object sender, EventArgs e)
        {

        }

        private void btnViewInternational_Click(object sender, EventArgs e)
        {

        }

        private void insertADomesticFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string insertQuery = "INSERT INTO tblFlights VALUES ('FlightNumber', 'Origin', 'DepartureTime', 'Destination', 'ArrivalTime', 'FlightDuration', 'Aircraft')";
            string selectQuery = "SELECT * FROM tblFlights";

            try
            {
                connect = new SqlConnection(connectionString);

                connect.Open();

                command = new SqlCommand(insertQuery, connect);
                command.ExecuteNonQuery();

                connect.Close();
                connect.Open();

                command = new SqlCommand(selectQuery, connect);
                data = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = command;
                adapter.Fill(data, "tblFlights");

                dataGridView1.DataSource = data;
                dataGridView1.DataMember = "tblFlights";

                connect.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void insertAnInternationalFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string insertQuery = "INSERT INTO tblFlights VALUES ('FlightNumber', 'Origin', 'DepartureTime', 'Destination', 'ArrivalTime', 'FlightDuration', 'Aircraft')";
            string selectQuery = "SELECT * FROM tblFlights";

            try
            {
                connect = new SqlConnection(connectionString);

                connect.Open();

                command = new SqlCommand(insertQuery, connect);
                command.ExecuteNonQuery();

                connect.Close();
                connect.Open();

                command = new SqlCommand(selectQuery, connect);
                data = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = command;
                adapter.Fill(data, "tblFlights");

                dataGridView1.DataSource = data;
                dataGridView1.DataMember = "tblFlights";

                connect.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}

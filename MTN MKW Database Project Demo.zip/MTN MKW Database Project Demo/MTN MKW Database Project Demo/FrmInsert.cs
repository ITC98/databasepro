﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MTN_MKW_Database_Project_Demo
{
    public partial class FrmInsert : Form
    {
        public FrmInsert()
        {
            InitializeComponent();
        }

        public char inputFlightNumber { get; set; }
        public string inputOrigin { get; set; }
        public char inputDepatureTime { get; set; }
        public string inputDestination { get; set; }
        public char inputArrivalTime { get; set; }
        public char inputFlightDuration { get; set; }
        public char inputAircraft { get; set; }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
        }
    }
}

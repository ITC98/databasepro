﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MTN_MKW_Database_Project_Demo
{
    public partial class FrmDatabase : Form
    {
        public FrmDatabase()
        {
            InitializeComponent();
        }

        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\School\Desktop\DB project\DB project\MTN MKW Database Project Demo(1)\MTN MKW Database Project Demo\MTN MKW Database Project Demo\flightDatabase.mdf;Integrated Security=True";
        public SqlConnection connect;
        public SqlCommand command;
        public SqlDataAdapter adapter;
        public DataSet data;

        private void btnViewAll_Click(object sender, EventArgs e)
        {
           
        }

        private void btnViewDomestic_Click(object sender, EventArgs e)
        {
            
        }

        private void btnViewInternational_Click(object sender, EventArgs e)
        {   

        }

        private void insertADomesticFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void insertAnInternationalFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {   

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string delete_query = "DELETE FROM tblFlights WHERE FlightNumber = '" + cboxDelete.SelectedValue + "'";
                string select_query = "SELECT * FROM tblFlights";

                SqlConnection connect = new SqlConnection(connectionString);

                connect.Open();

                adapter = new SqlDataAdapter();
                command = new SqlCommand(delete_query, connect);
                adapter.DeleteCommand = command;
                adapter.DeleteCommand.ExecuteNonQuery();


                connect.Close();

                connect.Open();

                command = new SqlCommand(select_query, connect);
                adapter = new SqlDataAdapter();
                DataSet data = new DataSet();
                adapter.SelectCommand = command;
                adapter.Fill(data, "tblFlights");

                dataGridView1.DataSource = data;
                dataGridView1.DataMember = "tblFlights";

                connect.Close();
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void cbxDomestic_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            SqlDataReader dataReader;
            string selectQuery; 

            connect.Open();
            selectQuery = "SELECT * FROM tblFlights";
            command = new SqlCommand(selectQuery, connect);
            dataReader = command.ExecuteReader();

            listBox1.Items.Add("Flight number" + "\t" + "Origin" + "\t" + "Departure time" + "\t" +  "Destination" + "\t" + "Arrival time" + "\t" + "Flight duration" + "\t" + "Aircraft");
            listBox1.Items.Add("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

            while(dataReader.Read())
            {
                if(dataReader.GetValue(0).ToString() == cbxDomestic.Text)
                {
                    listBox1.Items.Add(dataReader.GetValue(0) + "\t" + dataReader.GetValue(1) + "\t" + dataReader.GetValue(2) + "\t" + dataReader.GetValue(3) + "\t" + dataReader.GetValue(4) + "\t" + dataReader.GetValue(5) + "\t" + dataReader.GetValue(6) + "\t");
                }
            }
            connect.Close();
        }

        private void cboxDelete_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnFlightStatus_Click(object sender, EventArgs e)
        {

        }

        private void insertANewFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void buttonViewChecked_Click(object sender, EventArgs e)
        {
            try
            {
                if (rdBoxDomestic.Checked)
                {
                    string selectQuery = "SELECT * FROM tblFlights WHERE Aircraft = 'Airbus A321neo'";
                    connect.Open();

                    command = new SqlCommand(selectQuery, connect);
                    data = new DataSet();
                    adapter = new SqlDataAdapter();

                    adapter.SelectCommand = command;
                    adapter.Fill(data, "tblFlights");

                    dataGridView1.DataSource = data;
                    dataGridView1.DataMember = "tblFlights";

                    connect.Close();
                }
                else if (rdBoxInternational.Checked)
                {
                    string selectQuery = "SELECT * FROM tblFlights WHERE (Aircraft = 'Airbus A380-800' OR Aircraft = 'Airbus A350-900' OR Aircraft = 'Boeing 747-8' OR Aircraft = 'Boeing 787-9')";
                    
                    connect.Open();

                    command = new SqlCommand(selectQuery, connect);
                    data = new DataSet();
                    adapter = new SqlDataAdapter();

                    adapter.SelectCommand = command;
                    adapter.Fill(data, "tblFlights");

                    dataGridView1.DataSource = data;
                    dataGridView1.DataMember = "tblFlights";

                    connect.Close();
                }
                else if(rdBoxAll.Checked)
                {
                    string select_Query = "SELECT * FROM tblFlights";

                    try
                    {
                        connect = new SqlConnection(connectionString);

                        connect.Open();

                        command = new SqlCommand(select_Query, connect);
                        data = new DataSet();
                        adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;
                        adapter.Fill(data, "tblFlights");

                        dataGridView1.DataSource = data;
                        dataGridView1.DataMember = "tblFlights";

                        connect.Close();
                    }
                    catch (SqlException error)
                    {
                        MessageBox.Show(error.Message);
                    }
                }
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            FrmInsert insert = new FrmInsert();
            insert.ShowDialog();
            this.Hide();
        }

        private void FrmDatabase_Load(object sender, EventArgs e)
        {
            string select_Query = "SELECT * FROM tblFlights";

            try
            {
                connect = new SqlConnection(connectionString);

                connect.Open();

                command = new SqlCommand(select_Query, connect);
                data = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = command;
                adapter.Fill(data, "tblFlights");

                dataGridView1.DataSource = data;
                dataGridView1.DataMember = "tblFlights";

                connect.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

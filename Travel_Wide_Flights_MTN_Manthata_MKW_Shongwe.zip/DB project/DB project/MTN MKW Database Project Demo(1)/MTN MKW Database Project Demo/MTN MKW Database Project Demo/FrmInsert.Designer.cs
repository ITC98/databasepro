﻿namespace MTN_MKW_Database_Project_Demo
{
    partial class FrmInsert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.cBoxDestination = new System.Windows.Forms.ComboBox();
            this.cBoxAircraft = new System.Windows.Forms.ComboBox();
            this.txtFlightNumber = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.cBoxDepatureTime = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cBoxOrigin = new System.Windows.Forms.ComboBox();
            this.cBoxArrivalTime = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cBoxFlightDuration = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 232);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Flight Number:         MM";
            // 
            // cBoxDestination
            // 
            this.cBoxDestination.FormattingEnabled = true;
            this.cBoxDestination.Items.AddRange(new object[] {
            "Johannesbrug",
            "Cape Town",
            "Durban",
            "Port Elizabeth",
            "East London",
            "Bloemfontein",
            "Pretoria",
            "Pietermaritzburg",
            "Nelspruit",
            "Kimberley",
            "London",
            "Rome",
            "New York",
            "Miami",
            "Dubai",
            "Mumbai",
            "Hong Kong",
            "Singapore",
            "Sydney",
            "Sao Paulo"});
            this.cBoxDestination.Location = new System.Drawing.Point(127, 158);
            this.cBoxDestination.Name = "cBoxDestination";
            this.cBoxDestination.Size = new System.Drawing.Size(102, 21);
            this.cBoxDestination.TabIndex = 3;
            // 
            // cBoxAircraft
            // 
            this.cBoxAircraft.FormattingEnabled = true;
            this.cBoxAircraft.Items.AddRange(new object[] {
            "Airbus A321neo (195 passengers)",
            "Airbus A350-900 (265 passengers)",
            "Airbus A380-800 (490 passengers)",
            "Boeing 787-9 (245 passengers)",
            "Boeing 747-8 (370 passengers)"});
            this.cBoxAircraft.Location = new System.Drawing.Point(104, 258);
            this.cBoxAircraft.Name = "cBoxAircraft";
            this.cBoxAircraft.Size = new System.Drawing.Size(190, 21);
            this.cBoxAircraft.TabIndex = 4;
            // 
            // txtFlightNumber
            // 
            this.txtFlightNumber.Location = new System.Drawing.Point(199, 232);
            this.txtFlightNumber.Name = "txtFlightNumber";
            this.txtFlightNumber.Size = new System.Drawing.Size(95, 20);
            this.txtFlightNumber.TabIndex = 5;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(104, 320);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(91, 41);
            this.btnAdd.TabIndex = 6;
            this.btnAdd.Text = "&Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(294, 320);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(91, 41);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(40, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 18);
            this.label2.TabIndex = 8;
            this.label2.Text = "Origin:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(236, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "Depature Time:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(40, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 18);
            this.label4.TabIndex = 10;
            this.label4.Text = "Destination:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(40, 258);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 18);
            this.label7.TabIndex = 13;
            this.label7.Text = "Aircraft:";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(243, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "Arrival Time:";
            // 
            // cBoxDepatureTime
            // 
            this.cBoxDepatureTime.FormattingEnabled = true;
            this.cBoxDepatureTime.Items.AddRange(new object[] {
            "05:00",
            "05:15",
            "05:30",
            "05:45",
            "06:00",
            "06:15",
            "06:30",
            "06:45",
            "07:00",
            "07:15",
            "07:30",
            "07:45",
            "08:00",
            "08:15",
            "08:30",
            "08:45",
            "09:00",
            "09:15",
            "09:30",
            "09:45",
            "10:00",
            "10:15",
            "10:30",
            "10:45",
            "11:00",
            "11:15",
            "11:30",
            "11:45",
            "12:00",
            "12:15",
            "12:30",
            "12:45",
            "13:00",
            "13:15",
            "13:30",
            "13:45",
            "14:00",
            "14:15",
            "14:30",
            "14:45",
            "15:00",
            "15:15",
            "15:30",
            "15:45",
            "16:00",
            "16:15",
            "16:30",
            "16:45",
            "17:00",
            "17:15",
            "17:30",
            "17:45",
            "18:00",
            "18:15",
            "18:30",
            "18:45",
            "19:00",
            "19:15",
            "19:30",
            "19:45",
            "20:00",
            "20:15",
            "20:30",
            "20:45",
            "21:00",
            "21:15",
            "21:30",
            "21:45",
            "22:00",
            "22:15",
            "22:30",
            "22:45",
            "23:00",
            "23:15",
            "23:30",
            "23:45",
            "00:00"});
            this.cBoxDepatureTime.Location = new System.Drawing.Point(347, 127);
            this.cBoxDepatureTime.Name = "cBoxDepatureTime";
            this.cBoxDepatureTime.Size = new System.Drawing.Size(106, 21);
            this.cBoxDepatureTime.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Candara", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(121, 23);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(279, 39);
            this.label6.TabIndex = 20;
            this.label6.Text = "Travel Wide Flights";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(40, 93);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(148, 19);
            this.label8.TabIndex = 21;
            this.label8.Text = "Insert a new flight :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MTN_MKW_Database_Project_Demo.Properties.Resources.travel_globe;
            this.pictureBox1.Location = new System.Drawing.Point(13, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(97, 67);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // cBoxOrigin
            // 
            this.cBoxOrigin.FormattingEnabled = true;
            this.cBoxOrigin.Items.AddRange(new object[] {
            "Johannesburg",
            "Cape Town",
            "Durban",
            "Port Elizabeth",
            "East London",
            "Bloemfontein",
            "Pretoria",
            "Pietermaritzburg",
            "Nelspruit",
            "Kimberley",
            "London",
            "Rome",
            "New York",
            "Miami",
            "Dubai",
            "Mumbai",
            "Hong Kong",
            "Singapore",
            "Sydney",
            "Sao Paulo"});
            this.cBoxOrigin.Location = new System.Drawing.Point(127, 127);
            this.cBoxOrigin.Name = "cBoxOrigin";
            this.cBoxOrigin.Size = new System.Drawing.Size(103, 21);
            this.cBoxOrigin.TabIndex = 23;
            // 
            // cBoxArrivalTime
            // 
            this.cBoxArrivalTime.FormattingEnabled = true;
            this.cBoxArrivalTime.Items.AddRange(new object[] {
            "05:00",
            "05:15",
            "05:30",
            "05:45",
            "06:00",
            "06:15",
            "06:30",
            "06:45",
            "07:00",
            "07:15",
            "07:30",
            "07:45",
            "08:00",
            "08:15",
            "08:30",
            "08:45",
            "09:00",
            "09:15",
            "09:30",
            "09:45",
            "10:00",
            "10:15",
            "10:30",
            "10:45",
            "11:00",
            "11:15",
            "11:30",
            "11:45",
            "12:00",
            "12:15",
            "12:30",
            "12:45",
            "13:00",
            "13:15",
            "13:30",
            "13:45",
            "14:00",
            "14:15",
            "14:30",
            "14:45",
            "15:00",
            "15:15",
            "15:30",
            "15:45",
            "16:00",
            "16:15",
            "16:30",
            "16:45",
            "17:00",
            "17:15",
            "17:30",
            "17:45",
            "18:00",
            "18:15",
            "18:30",
            "18:45",
            "19:00",
            "19:15",
            "19:30",
            "19:45",
            "20:00",
            "20:15",
            "20:30",
            "20:45",
            "21:00",
            "21:15",
            "21:30",
            "21:45",
            "22:00",
            "22:15",
            "22:30",
            "22:45",
            "23:00",
            "23:15",
            "23:30",
            "23:45",
            "00:00"});
            this.cBoxArrivalTime.Location = new System.Drawing.Point(347, 157);
            this.cBoxArrivalTime.Name = "cBoxArrivalTime";
            this.cBoxArrivalTime.Size = new System.Drawing.Size(106, 21);
            this.cBoxArrivalTime.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(40, 192);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 18);
            this.label9.TabIndex = 25;
            this.label9.Text = "Flight Duration:";
            // 
            // cBoxFlightDuration
            // 
            this.cBoxFlightDuration.FormattingEnabled = true;
            this.cBoxFlightDuration.Items.AddRange(new object[] {
            "01h00m",
            "01h15m",
            "01h30m",
            "01h45m",
            "02h00m",
            "02h15m",
            "02h30m",
            "02h45m",
            "03h00m",
            "03h15m",
            "03h30m",
            "03h45m",
            "04h00m",
            "04h15m",
            "04h30m",
            "04h45m",
            "05h00m",
            "05h15m",
            "05h30m",
            "05h45m",
            "06h00m",
            "06h15m",
            "06h30m",
            "06h45m",
            "07h00m",
            "07h15m",
            "07h30m",
            "07h45m",
            "08h00m",
            "08h15m",
            "08h30m",
            "08h45m",
            "09h00m",
            "09h15m",
            "09h30m",
            "09h45m",
            "10h00m",
            "10h15m",
            "10h30m",
            "10h45m",
            "11h00m",
            "11h15m",
            "11h30m",
            "11h45m",
            "12h00m",
            "12h15m",
            "12h30m",
            "12h45m",
            "13h00m",
            "13h15m",
            "13h30m",
            "13h45m",
            "14h00m",
            "14h15m",
            "14h30m",
            "14h45m",
            "15h00m",
            "15h15m",
            "15h30m",
            "15h45m",
            "16h00m"});
            this.cBoxFlightDuration.Location = new System.Drawing.Point(149, 192);
            this.cBoxFlightDuration.Name = "cBoxFlightDuration";
            this.cBoxFlightDuration.Size = new System.Drawing.Size(106, 21);
            this.cBoxFlightDuration.TabIndex = 26;
            // 
            // FrmInsert
            // 
            this.AcceptButton = this.btnAdd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(502, 391);
            this.Controls.Add(this.cBoxFlightDuration);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cBoxArrivalTime);
            this.Controls.Add(this.cBoxOrigin);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtFlightNumber);
            this.Controls.Add(this.cBoxAircraft);
            this.Controls.Add(this.cBoxDestination);
            this.Controls.Add(this.cBoxDepatureTime);
            this.Controls.Add(this.label1);
            this.Name = "FrmInsert";
            this.Text = "Insert a New Flight";
            this.Load += new System.EventHandler(this.FrmInsert_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cBoxDestination;
        private System.Windows.Forms.ComboBox cBoxAircraft;
        private System.Windows.Forms.TextBox txtFlightNumber;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cBoxDepatureTime;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox cBoxOrigin;
        private System.Windows.Forms.ComboBox cBoxFlightDuration;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cBoxArrivalTime;
    }
}
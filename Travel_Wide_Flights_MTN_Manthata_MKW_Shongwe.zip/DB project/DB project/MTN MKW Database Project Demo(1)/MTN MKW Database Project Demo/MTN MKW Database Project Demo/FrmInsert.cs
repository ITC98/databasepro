﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MTN_MKW_Database_Project_Demo
{
    public partial class FrmInsert : Form
    {
        public FrmInsert()
        {
            InitializeComponent();
        }

        public string inputFlightNumber;
        public string inputOrigin;
        public string inputDepatureTime;
        public string inputDestination;
        public string inputArrivalTime;
        public string inputFlightDuration;
        public string inputAircraft;

        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\School\Desktop\DB project\DB project\MTN MKW Database Project Demo(1)\MTN MKW Database Project Demo\MTN MKW Database Project Demo\flightDatabase.mdf;Integrated Security=True";
        public SqlConnection connect;
        public SqlCommand command;
        public SqlDataAdapter adapter;
        public DataSet data;

        private void btnAdd_Click(object sender, EventArgs e)
        {
            inputOrigin = cBoxOrigin.Text;
            inputDepatureTime = cBoxDepatureTime.Text;
            inputDestination = cBoxDestination.Text;
            inputArrivalTime = cBoxArrivalTime.Text;
            inputAircraft = cBoxAircraft.Text;
            inputFlightNumber = txtFlightNumber.Text;
            
            try
            {
                string insertQuery = @"INSERT INTO tblFlights (FlightNumber, Origin, Departure Time, Destination, ArrivalTime, Aircraft)
                                      VALUES ('"+ inputFlightNumber + ","+ inputOrigin +","+ inputDepatureTime +","+ inputDestination +","+ inputArrivalTime +","+ inputFlightDuration +","+ inputAircraft +"')";

                connect = new SqlConnection(connectionString);

                connect.Open();

                command = new SqlCommand(insertQuery, connect);
                adapter = new SqlDataAdapter();
                
                data = new DataSet();

                adapter.Fill(data, "tblFlights");
                adapter.InsertCommand = command;
                adapter.InsertCommand.ExecuteNonQuery();

                connect.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            errorProvider1.SetError(txtFlightNumber, "Enter a valid flight number");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            FrmDatabase database = new FrmDatabase();
            database.ShowDialog();
        }

        private void FrmInsert_Load(object sender, EventArgs e)
        {
            
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {

        }
    }
}

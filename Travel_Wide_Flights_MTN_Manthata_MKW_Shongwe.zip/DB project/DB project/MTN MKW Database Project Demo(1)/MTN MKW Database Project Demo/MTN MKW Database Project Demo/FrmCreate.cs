﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MTN_MKW_Database_Project_Demo
{
    public partial class FrmCreate : Form
    {
        public SqlConnection connect;
        string connctionstring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\School\Desktop\DB project\DB project\MTN MKW Database Project Demo(1)\MTN MKW Database Project Demo\MTN MKW Database Project Demo\login.mdf;Integrated Security=True";

        public FrmCreate()
        {
            InitializeComponent();
        }

        private void btnCreate2_Click(object sender, EventArgs e)
        {
            string passwordConfrim, passwordCreate, UserName;

            passwordConfrim = txtPasswordConfirm.Text;
            passwordCreate = txtPasswordCreate.Text;
            UserName = txtUsernameCreate.Text;
          
            try
            {
                FrmLogin login = new FrmLogin();
                FrmCreate create = new FrmCreate();
                login.ShowDialog();
                create.Hide();

                connect = new SqlConnection(connctionstring);
                connect.Open();
                SqlCommand command = new SqlCommand("INSERT INTO TblLogin(Username , Password) VALUES('" + UserName + "','" + passwordConfrim + "') ", connect);

                SqlDataAdapter adapter = new SqlDataAdapter();

                adapter.InsertCommand = command;
                adapter.InsertCommand.ExecuteNonQuery();
                connect.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            FrmLogin login = new FrmLogin();
            login.ShowDialog();
            this.Hide();
        }

        private void btnClear2_Click(object sender, EventArgs e)
        {
            txtUsernameCreate.Clear();
            txtPasswordCreate.Clear();
            txtPasswordConfirm.Clear();

            txtUsernameCreate.Focus();
        }
    }
}

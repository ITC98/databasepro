﻿namespace MTN_MKW_Database_Project_Demo
{
    partial class FrmDatabase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnDelete = new System.Windows.Forms.Button();
            this.tabControlView = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonViewChecked = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cboxDelete = new System.Windows.Forms.ComboBox();
            this.tabPageSearch = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.cbxDomestic = new System.Windows.Forms.ComboBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFlightStatus = new System.Windows.Forms.Button();
            this.btnInsert = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.rdBoxAll = new System.Windows.Forms.RadioButton();
            this.rdBoxDomestic = new System.Windows.Forms.RadioButton();
            this.rdBoxInternational = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControlView.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPageSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(5, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(756, 315);
            this.dataGridView1.TabIndex = 1;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(313, 409);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(87, 49);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "&Delete an Existing Flight";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabControlView
            // 
            this.tabControlView.Controls.Add(this.tabPage1);
            this.tabControlView.Controls.Add(this.tabPageSearch);
            this.tabControlView.Location = new System.Drawing.Point(9, 75);
            this.tabControlView.Margin = new System.Windows.Forms.Padding(2);
            this.tabControlView.Name = "tabControlView";
            this.tabControlView.SelectedIndex = 0;
            this.tabControlView.Size = new System.Drawing.Size(775, 494);
            this.tabControlView.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.rdBoxInternational);
            this.tabPage1.Controls.Add(this.rdBoxDomestic);
            this.tabPage1.Controls.Add(this.rdBoxAll);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.buttonViewChecked);
            this.tabPage1.Controls.Add(this.btnDelete);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.cboxDelete);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(767, 468);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Display";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(49, 397);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 18);
            this.label6.TabIndex = 14;
            this.label6.Text = "Delete:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(49, 334);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 18);
            this.label5.TabIndex = 13;
            this.label5.Text = "View:";
            // 
            // buttonViewChecked
            // 
            this.buttonViewChecked.Location = new System.Drawing.Point(475, 352);
            this.buttonViewChecked.Margin = new System.Windows.Forms.Padding(2);
            this.buttonViewChecked.Name = "buttonViewChecked";
            this.buttonViewChecked.Size = new System.Drawing.Size(87, 35);
            this.buttonViewChecked.TabIndex = 11;
            this.buttonViewChecked.Text = "&View";
            this.buttonViewChecked.UseVisualStyleBackColor = true;
            this.buttonViewChecked.Click += new System.EventHandler(this.buttonViewChecked_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(49, 424);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 18);
            this.label2.TabIndex = 8;
            this.label2.Text = "Flight Number:";
            // 
            // cboxDelete
            // 
            this.cboxDelete.FormattingEnabled = true;
            this.cboxDelete.Items.AddRange(new object[] {
            "MM109",
            "MM110",
            "MM111",
            "MM112",
            "MM113",
            "MM114",
            "MM115",
            "MM116",
            "MM117",
            "MM118",
            "MM119",
            "MM120",
            "MM121",
            "MM122",
            "MM123",
            "MM124",
            "MM125",
            "MM126",
            "MM127",
            "MM128",
            "MM129"});
            this.cboxDelete.Location = new System.Drawing.Point(153, 424);
            this.cboxDelete.Margin = new System.Windows.Forms.Padding(2);
            this.cboxDelete.Name = "cboxDelete";
            this.cboxDelete.Size = new System.Drawing.Size(128, 21);
            this.cboxDelete.TabIndex = 7;
            this.cboxDelete.SelectedIndexChanged += new System.EventHandler(this.cboxDelete_SelectedIndexChanged);
            // 
            // tabPageSearch
            // 
            this.tabPageSearch.Controls.Add(this.label3);
            this.tabPageSearch.Controls.Add(this.cbxDomestic);
            this.tabPageSearch.Controls.Add(this.listBox1);
            this.tabPageSearch.Controls.Add(this.label1);
            this.tabPageSearch.Location = new System.Drawing.Point(4, 22);
            this.tabPageSearch.Margin = new System.Windows.Forms.Padding(2);
            this.tabPageSearch.Name = "tabPageSearch";
            this.tabPageSearch.Padding = new System.Windows.Forms.Padding(2);
            this.tabPageSearch.Size = new System.Drawing.Size(767, 468);
            this.tabPageSearch.TabIndex = 1;
            this.tabPageSearch.Text = "Search";
            this.tabPageSearch.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(51, 61);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 18);
            this.label3.TabIndex = 11;
            this.label3.Text = "Flight Number:";
            // 
            // cbxDomestic
            // 
            this.cbxDomestic.FormattingEnabled = true;
            this.cbxDomestic.Items.AddRange(new object[] {
            "MM109",
            "MM110",
            "MM111",
            "MM112",
            "MM113",
            "MM114",
            "MM115",
            "MM116",
            "MM117",
            "MM118",
            "MM119",
            "MM120",
            "MM121",
            "MM122",
            "MM123",
            "MM124",
            "MM125",
            "MM126",
            "MM127",
            "MM128",
            "MM129"});
            this.cbxDomestic.Location = new System.Drawing.Point(155, 61);
            this.cbxDomestic.Margin = new System.Windows.Forms.Padding(2);
            this.cbxDomestic.Name = "cbxDomestic";
            this.cbxDomestic.Size = new System.Drawing.Size(120, 21);
            this.cbxDomestic.TabIndex = 8;
            this.cbxDomestic.SelectedIndexChanged += new System.EventHandler(this.cbxDomestic_SelectedIndexChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(19, 117);
            this.listBox1.Margin = new System.Windows.Forms.Padding(2);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(726, 121);
            this.listBox1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "Search for a Flight";
            // 
            // btnFlightStatus
            // 
            this.btnFlightStatus.Location = new System.Drawing.Point(803, 208);
            this.btnFlightStatus.Margin = new System.Windows.Forms.Padding(2);
            this.btnFlightStatus.Name = "btnFlightStatus";
            this.btnFlightStatus.Size = new System.Drawing.Size(87, 49);
            this.btnFlightStatus.TabIndex = 7;
            this.btnFlightStatus.Text = "&Check for Flight Status";
            this.btnFlightStatus.UseVisualStyleBackColor = true;
            this.btnFlightStatus.Click += new System.EventHandler(this.btnFlightStatus_Click);
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(803, 135);
            this.btnInsert.Margin = new System.Windows.Forms.Padding(2);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(87, 49);
            this.btnInsert.TabIndex = 8;
            this.btnInsert.Text = "Insert a &New Flight ";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Candara", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(168, 20);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(447, 42);
            this.label4.TabIndex = 12;
            this.label4.Text = "Travel Wide Flights database";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MTN_MKW_Database_Project_Demo.Properties.Resources.travel_globe;
            this.pictureBox1.Location = new System.Drawing.Point(32, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 60);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // rdBoxAll
            // 
            this.rdBoxAll.AutoSize = true;
            this.rdBoxAll.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdBoxAll.Location = new System.Drawing.Point(52, 359);
            this.rdBoxAll.Name = "rdBoxAll";
            this.rdBoxAll.Size = new System.Drawing.Size(82, 22);
            this.rdBoxAll.TabIndex = 15;
            this.rdBoxAll.TabStop = true;
            this.rdBoxAll.Text = "All flights";
            this.rdBoxAll.UseVisualStyleBackColor = true;
            // 
            // rdBoxDomestic
            // 
            this.rdBoxDomestic.AutoSize = true;
            this.rdBoxDomestic.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdBoxDomestic.Location = new System.Drawing.Point(162, 359);
            this.rdBoxDomestic.Name = "rdBoxDomestic";
            this.rdBoxDomestic.Size = new System.Drawing.Size(126, 22);
            this.rdBoxDomestic.TabIndex = 16;
            this.rdBoxDomestic.TabStop = true;
            this.rdBoxDomestic.Text = "Domestic flights";
            this.rdBoxDomestic.UseVisualStyleBackColor = true;
            // 
            // rdBoxInternational
            // 
            this.rdBoxInternational.AutoSize = true;
            this.rdBoxInternational.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdBoxInternational.Location = new System.Drawing.Point(313, 358);
            this.rdBoxInternational.Name = "rdBoxInternational";
            this.rdBoxInternational.Size = new System.Drawing.Size(146, 22);
            this.rdBoxInternational.TabIndex = 17;
            this.rdBoxInternational.TabStop = true;
            this.rdBoxInternational.Text = "International flights";
            this.rdBoxInternational.UseVisualStyleBackColor = true;
            // 
            // FrmDatabase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 576);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.btnFlightStatus);
            this.Controls.Add(this.tabControlView);
            this.Name = "FrmDatabase";
            this.Text = "Database";
            this.Load += new System.EventHandler(this.FrmDatabase_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControlView.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPageSearch.ResumeLayout(false);
            this.tabPageSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TabControl tabControlView;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPageSearch;
        private System.Windows.Forms.ComboBox cbxDomestic;
        private System.Windows.Forms.ComboBox cboxDelete;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnFlightStatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonViewChecked;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rdBoxInternational;
        private System.Windows.Forms.RadioButton rdBoxDomestic;
        private System.Windows.Forms.RadioButton rdBoxAll;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MTN_MKW_Database_Project_Demo
{
    public partial class FrmCreate : Form
    {
        public FrmCreate()
        {
            InitializeComponent();
        }

        public string passwordCreate { get; set; }
        public string passwordConfrim { get; set; }

        //string name = FrmLogin.


        private void btnCreate2_Click(object sender, EventArgs e)
        {
            if (passwordConfrim == passwordCreate)
            {
                FrmLogin login = new FrmLogin();
                login.ShowDialog();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Passwords don't match, please re-enter password");
                txtPasswordCreate.Clear();
                txtPasswordConfirm.Clear();
                txtPasswordCreate.Focus();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            FrmLogin login = new FrmLogin();
            login.ShowDialog();
            this.Hide();
        }

        private void btnClear2_Click(object sender, EventArgs e)
        {
            txtUsernameCreate.Clear();
            txtPasswordCreate.Clear();
            txtPasswordConfirm.Clear();

            txtUsernameCreate.Focus();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MTN_MKW_Database_Project_Demo
{
    public partial class FrmInsert : Form
    {
        public FrmInsert()
        {
            InitializeComponent();
        }

        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\School\Desktop\DB project\MTN MKW Database Project Demo(1)\MTN MKW Database Project Demo\MTN MKW Database Project Demo\flightDatabase.mdf;Integrated Security=True";
        public SqlConnection connect;
        public SqlCommand command;
        public SqlDataAdapter adapter;
        public DataSet data;

        public int inputFlightNumber;
        public string inputOrigin;
        public string inputDepatureTime;
        public string inputDestination;
        //public string inputArrivalTime;
       // public string inputFlightDuration;
        public string inputAircraft;

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // code for activity 8

            errorProvider1.SetError(txtFlightNumber, "");
            if(int.TryParse(txtFlightNumber.Text, out inputFlightNumber))
            {
                inputAircraft = cBoxAircraft.Text;
                inputDepatureTime = cBoxDepatureTime.Text;
                inputDestination = cBoxDestination.Text;
                // delete the arrival time and flight durationn calculations 
                //inputArrivalTime =
            }
            else
            {
                txtFlightNumber.Text = "";
                errorProvider1.SetError(txtFlightNumber, "Please enter a valid fight number");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmInsert_Load(object sender, EventArgs e)
        {
            //Number of passengers
            hScrollBar1.Value = 0;
            hScrollBar1.Minimum = 0;
            hScrollBar1.Maximum = 490;
            hScrollBar1.LargeChange = 1;
            hScrollBar1.SmallChange = 1;
            // display intial value
            lblpassengers.Text = hScrollBar1.Value.ToString();
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            //display the scroll bar value;
            lblpassengers.Text = hScrollBar1.ToString();

        }
    }
}

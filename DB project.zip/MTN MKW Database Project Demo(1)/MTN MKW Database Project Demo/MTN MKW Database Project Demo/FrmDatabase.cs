﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MTN_MKW_Database_Project_Demo
{
    public partial class FrmDatabase : Form
    {
        public FrmDatabase()
        {
            InitializeComponent();
        }

        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\30550602\Desktop\MTN MKW Database Project Demo\MTN MKW Database Project Demo\flightDatabase.mdf;Integrated Security=True";
        public SqlConnection connect;
        public SqlCommand command;
        public SqlDataAdapter adapter;
        public DataSet data;

        private void btnViewAll_Click(object sender, EventArgs e)
        {
           
        }

        private void btnViewDomestic_Click(object sender, EventArgs e)
        {
            // name all the domestic flights
            string selectQuery = "SELECT * FROM tblFlights";
            try
            {
                connect.Open();

                command = new SqlCommand(selectQuery, connect);
                data = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = command;
                adapter.Fill(data, "tblFlights");

                dataGridView1.DataSource = data;
                dataGridView1.DataMember = "tblFlights";

                connect.Close();
            }
            catch
            {

            }
        }

        private void btnViewInternational_Click(object sender, EventArgs e)
        {// name all the filghts
            string selectQuery = "SELECT * FROM tblFlights WHERE Origin = 'Johanessburg',''  ";
            try
            {
                connect.Open();

                command = new SqlCommand(selectQuery, connect);
                data = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = command;
                adapter.Fill(data, "tblFlights");

                dataGridView1.DataSource = data;
                dataGridView1.DataMember = "tblFlights";

                connect.Close();
            }
            catch
            {

            }
        }

        private void insertADomesticFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmInsert myAdd= new FrmInsert();
            myAdd.ShowDialog();

            int FlightNumber1 = Convert.ToInt32(myAdd.inputFlightNumber);
            string Orgin1 =myAdd.inputOrigin;
            string destination1 = myAdd.inputDestination;
            string departureTime1 = myAdd.inputDepatureTime;
            //string arrivalTime = myAdd.inputDepatureTime;
            string Aircraft = myAdd.inputAircraft;


            // check this string for insert
            //string insertQuery = "INSERT INTO tblFlights VALUES ('" + 'FlightNumber'+ "',"+  'Origin,+ 'DepartureTime', 'Destination', 'ArrivalTime','FlightDuration', Aircraft+"')";
            string selectQuery = "SELECT * FROM tblFlights";

            try
            {
                // used activity 8
                connect = new SqlConnection(connectionString);

                connect.Open();

               // command = new SqlCommand(insertQuery, connect);
                adapter = new SqlDataAdapter();

                adapter.InsertCommand = command;
                adapter.InsertCommand.ExecuteNonQuery();


                MessageBox.Show("Inserted sucessfully ");
               

              
               
                
              //  adapter.SelectCommand = command;
              //  adapter.Fill(data, "tblFlights");

               // dataGridView1.DataSource = data;
              //  dataGridView1.DataMember = "tblFlights";

               // connect.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void insertAnInternationalFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string insertQuery = "INSERT INTO tblFlights VALUES ('FlightNumber', 'Origin', 'DepartureTime', 'Destination', 'ArrivalTime', 'FlightDuration', 'Aircraft')";
            string selectQuery = "SELECT * FROM tblFlights";

            try
            {
                connect = new SqlConnection(connectionString);

                connect.Open();

                command = new SqlCommand(insertQuery, connect);
                command.ExecuteNonQuery();

                connect.Close();
                connect.Open();

                command = new SqlCommand(selectQuery, connect);
                data = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = command;
                adapter.Fill(data, "tblFlights");

                dataGridView1.DataSource = data;
                dataGridView1.DataMember = "tblFlights";

                connect.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // deletes the record off the database
            try
            {
                string delete_query = "DELETE FROM tblFlights WHERE FlightNumber = '" + cboxDelete.Text + "' ";
                string select_query = "SELECT * FROM tblFlights";

                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(delete_query, con);

                command.ExecuteNonQuery();
                con.Close();
                connect.Open();

                command = new SqlCommand(select_query, connect);
                data = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = command;
                adapter.Fill(data, "tblFlights");

                dataGridView1.DataSource = data;
                dataGridView1.DataMember = "tblFlights";

                connect.Close();


            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void cbxDomestic_SelectedIndexChanged(object sender, EventArgs e)
        {
            // displays all flights that and you search for a flight number or 
            listBox1.Items.Clear();

            SqlCommand command;
            SqlDataReader dataReader;
            string selectQuery, output = "";

            connect.Open();
            selectQuery = "SELECT *FROM tblFlights";
            command = new SqlCommand(selectQuery, connect);
            dataReader = command.ExecuteReader();

            listBox1.Items.Add("Flight number" + "\t" + "\t" + "Origin" + "\t" + "Departure time" + "\t" +  "Destination");
            listBox1.Items.Add("-------------------------------------------------------------------------");

            while(dataReader.Read())
            {
                if(dataReader.GetValue(1).ToString() == cbxDomestic.Text)
                {
                    listBox1.Items.Add(dataReader.GetValue(0) + "\t" + dataReader.GetValue(1) + "\t" + dataReader.GetValue(2) + "\t" + dataReader.GetValue(3) + "\t" + dataReader.GetValue(4) + "\t" + dataReader.GetValue(5) + "\t" + dataReader.GetValue(6) + "\t");

                }
            }
            connect.Close();
        }

        private void cboxDelete_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnFlightStatus_Click(object sender, EventArgs e)
        {
            FrmStatus myfrm = new FrmStatus();
            myfrm.MdiParent = this;
            myfrm.Show();
            this.Hide();

        }

        private void insertANewFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void buttonViewChecked_Click(object sender, EventArgs e)
        {// name all domestic flights
          
            try
            {
                if (chckBoxdomestic.Checked)
                {
                    string selectQuery = "SELECT * FROM tblFlights WHERE VALUES ";
                    connect.Open();

                    command = new SqlCommand(selectQuery, connect);
                    data = new DataSet();
                    adapter = new SqlDataAdapter();

                    adapter.SelectCommand = command;
                    adapter.Fill(data, "tblFlights");

                    dataGridView1.DataSource = data;
                    dataGridView1.DataMember = "tblFlights";

                    connect.Close();
                }
                else if (chckBoxInternational.Checked)
                {
                    string selectQuery = "SELECT * FROM tblFlights WHERE VALUES ";
                    connect.Open();

                    command = new SqlCommand(selectQuery, connect);
                    data = new DataSet();
                    adapter = new SqlDataAdapter();

                    adapter.SelectCommand = command;
                    adapter.Fill(data, "tblFlights");

                    dataGridView1.DataSource = data;
                    dataGridView1.DataMember = "tblFlights";

                    connect.Close();

                }
                else if(chckBoxAll.Checked)
                {
                    string select_Query = "SELECT * FROM tblFlights";

                    try
                    {
                        connect = new SqlConnection(connectionString);

                        connect.Open();

                        command = new SqlCommand(select_Query, connect);
                        data = new DataSet();
                        adapter = new SqlDataAdapter();

                        adapter.SelectCommand = command;
                        adapter.Fill(data, "tblFlights");

                        dataGridView1.DataSource = data;
                        dataGridView1.DataMember = "tblFlights";

                        connect.Close();
                    }
                    catch (SqlException error)
                    {
                        MessageBox.Show(error.Message);
                    }
                }
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
            
           

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            FrmInsert insert = new FrmInsert();
            insert.ShowDialog();
            this.Hide();
           
        }
    }
}

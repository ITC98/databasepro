﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MTN_MKW_Database_Project_Demo
{
    public partial class FrmStatus : Form
    {
        public FrmStatus()
        {
            InitializeComponent();
        }
        SqlConnection myDB;
        
        private void FrmStatus_Load(object sender, EventArgs e)
        {
            string connectionstring = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\keitumetse\Downloads\MTN MKW Database Project Demo(1)\MTN MKW Database Project Demo\MTN MKW Database Project Demo\flightDatabase.mdf; Integrated Security = True";
            myDB = new SqlConnection(connectionstring);
            
           
        }
    }
}

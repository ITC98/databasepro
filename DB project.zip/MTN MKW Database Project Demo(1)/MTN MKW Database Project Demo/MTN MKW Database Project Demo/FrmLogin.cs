﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MTN_MKW_Database_Project_Demo
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        public string username, password;

        private void btnCreate_Click(object sender, EventArgs e)
        {
            FrmCreate create = new FrmCreate();
            create.ShowDialog();
            this.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();

            txtUsername.Focus();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            username = txtUsername.Text;
            password = txtPassword.Text;

            try
            {
                if ((string.IsNullOrEmpty(username)) && (string.IsNullOrEmpty(password)))
                {
                    MessageBox.Show("Type in your details");
                }
                else
                {
                    FrmCreate create = new FrmCreate();
                    string passwordOne = create.passwordConfrim;

                    if (password == passwordOne)
                    {
                        MessageBox.Show("Login successful!");
                        FrmDatabase database = new FrmDatabase();
                        database.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Passwords do not match, re-enter passwords");
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

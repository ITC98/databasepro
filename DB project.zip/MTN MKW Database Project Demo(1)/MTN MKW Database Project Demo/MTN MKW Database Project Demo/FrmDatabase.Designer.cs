﻿namespace MTN_MKW_Database_Project_Demo
{
    partial class FrmDatabase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.tabControlView = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPageSearch = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.cboxDelete = new System.Windows.Forms.ComboBox();
            this.cbxDomestic = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnFlightStatus = new System.Windows.Forms.Button();
            this.chckBoxInternational = new System.Windows.Forms.CheckBox();
            this.chckBoxdomestic = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonViewChecked = new System.Windows.Forms.Button();
            this.chckBoxAll = new System.Windows.Forms.CheckBox();
            this.btnInsert = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControlView.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPageSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(17, 25);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(718, 340);
            this.dataGridView1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(309, 391);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 48);
            this.button1.TabIndex = 5;
            this.button1.Text = "Delete an Existing Flight";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabControlView
            // 
            this.tabControlView.Controls.Add(this.tabPage1);
            this.tabControlView.Controls.Add(this.tabPageSearch);
            this.tabControlView.Location = new System.Drawing.Point(12, 92);
            this.tabControlView.Name = "tabControlView";
            this.tabControlView.SelectedIndex = 0;
            this.tabControlView.Size = new System.Drawing.Size(908, 554);
            this.tabControlView.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.chckBoxAll);
            this.tabPage1.Controls.Add(this.buttonViewChecked);
            this.tabPage1.Controls.Add(this.chckBoxdomestic);
            this.tabPage1.Controls.Add(this.chckBoxInternational);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.cboxDelete);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(900, 525);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Display";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPageSearch
            // 
            this.tabPageSearch.Controls.Add(this.label3);
            this.tabPageSearch.Controls.Add(this.cbxDomestic);
            this.tabPageSearch.Controls.Add(this.listBox1);
            this.tabPageSearch.Controls.Add(this.label1);
            this.tabPageSearch.Location = new System.Drawing.Point(4, 25);
            this.tabPageSearch.Name = "tabPageSearch";
            this.tabPageSearch.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSearch.Size = new System.Drawing.Size(900, 525);
            this.tabPageSearch.TabIndex = 1;
            this.tabPageSearch.Text = "Search";
            this.tabPageSearch.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Search for a flights:";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(16, 156);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(853, 148);
            this.listBox1.TabIndex = 6;
            // 
            // cboxDelete
            // 
            this.cboxDelete.FormattingEnabled = true;
            this.cboxDelete.Items.AddRange(new object[] {
            "MM109",
            "MM110",
            "MM111",
            "MM112",
            "MM113",
            "MM114",
            "MM115",
            "MM116",
            "MM117",
            "MM118",
            "MM119",
            "MM120",
            "MM121",
            "MM122",
            "MM123",
            "MM124",
            "MM125",
            "MM126",
            "MM127",
            "MM128",
            "MM129"});
            this.cboxDelete.Location = new System.Drawing.Point(112, 404);
            this.cboxDelete.Name = "cboxDelete";
            this.cboxDelete.Size = new System.Drawing.Size(169, 24);
            this.cboxDelete.TabIndex = 7;
            this.cboxDelete.SelectedIndexChanged += new System.EventHandler(this.cboxDelete_SelectedIndexChanged);
            // 
            // cbxDomestic
            // 
            this.cbxDomestic.FormattingEnabled = true;
            this.cbxDomestic.Items.AddRange(new object[] {
            "MM109",
            "MM110",
            "MM111",
            "MM112",
            "MM113",
            "MM114",
            "MM115",
            "MM116",
            "MM117",
            "MM118",
            "MM119",
            "MM120",
            "MM121",
            "MM122",
            "MM123",
            "MM124",
            "MM125",
            "MM126",
            "MM127",
            "MM128",
            "MM129"});
            this.cbxDomestic.Location = new System.Drawing.Point(220, 72);
            this.cbxDomestic.Name = "cbxDomestic";
            this.cbxDomestic.Size = new System.Drawing.Size(158, 24);
            this.cbxDomestic.TabIndex = 8;
            this.cbxDomestic.SelectedIndexChanged += new System.EventHandler(this.cbxDomestic_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 399);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Flight Number:";
            // 
            // btnFlightStatus
            // 
            this.btnFlightStatus.Location = new System.Drawing.Point(939, 208);
            this.btnFlightStatus.Name = "btnFlightStatus";
            this.btnFlightStatus.Size = new System.Drawing.Size(116, 43);
            this.btnFlightStatus.TabIndex = 7;
            this.btnFlightStatus.Text = "Check for flight status";
            this.btnFlightStatus.UseVisualStyleBackColor = true;
            this.btnFlightStatus.Click += new System.EventHandler(this.btnFlightStatus_Click);
            // 
            // chckBoxInternational
            // 
            this.chckBoxInternational.AutoSize = true;
            this.chckBoxInternational.Location = new System.Drawing.Point(388, 484);
            this.chckBoxInternational.Name = "chckBoxInternational";
            this.chckBoxInternational.Size = new System.Drawing.Size(142, 21);
            this.chckBoxInternational.TabIndex = 9;
            this.chckBoxInternational.Text = "International flight";
            this.chckBoxInternational.UseVisualStyleBackColor = true;
            // 
            // chckBoxdomestic
            // 
            this.chckBoxdomestic.AutoSize = true;
            this.chckBoxdomestic.Location = new System.Drawing.Point(216, 484);
            this.chckBoxdomestic.Name = "chckBoxdomestic";
            this.chckBoxdomestic.Size = new System.Drawing.Size(122, 21);
            this.chckBoxdomestic.TabIndex = 10;
            this.chckBoxdomestic.Text = "Domestic flight";
            this.chckBoxdomestic.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(73, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Flight Number:";
            // 
            // buttonViewChecked
            // 
            this.buttonViewChecked.Location = new System.Drawing.Point(575, 474);
            this.buttonViewChecked.Name = "buttonViewChecked";
            this.buttonViewChecked.Size = new System.Drawing.Size(151, 38);
            this.buttonViewChecked.TabIndex = 11;
            this.buttonViewChecked.Text = "View";
            this.buttonViewChecked.UseVisualStyleBackColor = true;
            this.buttonViewChecked.Click += new System.EventHandler(this.buttonViewChecked_Click);
            // 
            // chckBoxAll
            // 
            this.chckBoxAll.AutoSize = true;
            this.chckBoxAll.Location = new System.Drawing.Point(78, 484);
            this.chckBoxAll.Name = "chckBoxAll";
            this.chckBoxAll.Size = new System.Drawing.Size(86, 21);
            this.chckBoxAll.TabIndex = 12;
            this.chckBoxAll.Text = "All flights";
            this.chckBoxAll.UseVisualStyleBackColor = true;
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(926, 142);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(127, 39);
            this.btnInsert.TabIndex = 8;
            this.btnInsert.Text = "Insert a new flight ";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(223, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(595, 52);
            this.label4.TabIndex = 12;
            this.label4.Text = "Travel Wide flights database";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(43, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(133, 74);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // FrmDatabase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 655);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.btnFlightStatus);
            this.Controls.Add(this.tabControlView);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmDatabase";
            this.Text = "Database";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControlView.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPageSearch.ResumeLayout(false);
            this.tabPageSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControlView;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPageSearch;
        private System.Windows.Forms.ComboBox cbxDomestic;
        private System.Windows.Forms.ComboBox cboxDelete;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnFlightStatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chckBoxInternational;
        private System.Windows.Forms.CheckBox chckBoxdomestic;
        private System.Windows.Forms.Button buttonViewChecked;
        private System.Windows.Forms.CheckBox chckBoxAll;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}